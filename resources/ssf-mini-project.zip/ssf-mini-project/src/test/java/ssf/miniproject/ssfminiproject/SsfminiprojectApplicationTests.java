package ssf.miniproject.ssfminiproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsfminiprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
